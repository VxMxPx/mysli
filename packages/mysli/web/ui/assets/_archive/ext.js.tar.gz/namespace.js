mysli               = typeof mysli               === 'object' ? mysli               : {};
mysli.web           = typeof mysli.web           === 'object' ? mysli.web           : {};
mysli.web.ui        = typeof mysli.web.ui        === 'object' ? mysli.web.ui        : {};
mysli.web.ui.mixins = typeof mysli.web.ui.mixins === 'object' ? mysli.web.ui.mixins : {};
