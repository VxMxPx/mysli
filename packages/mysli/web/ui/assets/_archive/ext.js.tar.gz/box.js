mysli.web.ui.box = (function () {

    'use strict';
    var ui = mysli.web.ui,
        template = '<div class="ui-box ui-widget"></div>';


    var self = function (options) {

        this.HORIZONTAL = 'orientation-horizontal';
        this.VERTICAL   = 'orientation-vertical';
        this.START = 'position-start';
        this.END = 'position-end';

        console.log(this);
        this.elements.push($(template));

        this.set_orientation(options.orientation || this.HORIZONTAL);
        if (this.orientation === this.VERTICAL) {
            var row = $('<div class="row" />');
            this.get_element().append(row);
            this.container.master = row;
            this.container.target = row;
        } else {
            this.container.master = this.get_element();
            this.container.target = this.get_element();
        }
    };

    ui.mixins.container.call(self.prototype);

    self.prototype.constructor = self;

    /// Sets orientation for box. This can be called only once.
    /// @param {string} orientation
    self.prototype.set_orientation = function (orientation) {

        if (this.orientation) {
            throw new Error('Orientation is already set.');
        }

        if (orientation === this.HORIZONTAL) {
            this.orientation = this.HORIZONTAL;
        } else if (orientation === this.VERTICAL) {
            this.orientation = this.VERTICAL;
        } else {
            throw new Error('Invalid `orientation` value.');
        }
    };
    /// Add widget to the box
    /// @param {object} widget
    /// @param {string} position (this.START, this.END)
    /// @returns {integer} id
    self.prototype.add = function (element, position) {

        var parent;

        if (this.orientation === this.HORIZONTAL) {
            parent = $('<div class="row" />');
        } else {
            parent = $('<div class="cell" />');
        }
        this.container
            .master[position===this.START ? 'prepend' : 'append'](parent);
        this.container.target = parent;

        return this.prototype.prototype.add(element);
    };

    return self;
}());
