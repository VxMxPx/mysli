mysli.web.ui.button = (function () {

    'use strict';

    var self = function () {};
    mysli.web.ui.mixins.button.call(self.prototype);

    return self;
}());
