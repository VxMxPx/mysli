<?php

namespace mysli\util\curl\exception {
    class curl extends \mysli\framework\exception\base {}
}
