<?php

namespace mysli\util\tplp\exception {
    class parser extends \mysli\framework\exception\base {}
}
