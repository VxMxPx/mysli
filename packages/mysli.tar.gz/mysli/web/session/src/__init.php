<?php

namespace mysli\web\session;

function __init()
{
    session::discover();
}
