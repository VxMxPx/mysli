<?php

namespace mysli\web\response\exception;

class response extends mysli\framework\exception\base {}
