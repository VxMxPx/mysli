/// <reference path="../../../assets/js/_jquery.d.ts" />
declare module mysli.js.common {
    function mix(defaults: any, options?: any): any;
}
