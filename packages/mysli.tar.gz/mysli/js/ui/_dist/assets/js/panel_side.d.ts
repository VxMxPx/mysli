/// <reference path="container.d.ts" />
declare module mysli.js.ui {
    class PanelSide extends Container {
        constructor(options?: any);
    }
}
