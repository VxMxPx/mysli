<?php

namespace mysli\framework\type;

__use(__namespace__, '
    ./str
');

function __init()
{
    str::encoding('UTF-8');
}
