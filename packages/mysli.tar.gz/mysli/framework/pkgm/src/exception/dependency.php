<?php

namespace mysli\framework\pkgm\exception {
    class dependency extends \mysli\framework\exception\base {}
}
