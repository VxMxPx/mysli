<?php

namespace mysli\framework\pkgm\exception {
    class package extends \mysli\framework\exception\base {}
}
