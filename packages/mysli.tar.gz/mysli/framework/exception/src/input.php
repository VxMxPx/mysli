<?php

namespace mysli\framework\exception {
    class input extends base {}
}
