<?php

namespace mysli\framework\exception {
    class fs extends base {}
}
