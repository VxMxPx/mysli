<?php

namespace mysli\framework\exception {
    class argument extends base {}
}
