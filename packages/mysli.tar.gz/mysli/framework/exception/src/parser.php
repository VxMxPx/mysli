<?php

namespace mysli\framework\exception {
    class parser extends base {}
}
