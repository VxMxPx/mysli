<?php

namespace mysli\framework\exception {
    class base extends \Exception {}
}
