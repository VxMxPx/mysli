<?php

namespace mysli\framework\exception {
    class data extends base {}
}
