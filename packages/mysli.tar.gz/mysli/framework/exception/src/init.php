<?php

namespace mysli\framework\exception {
    class init extends base {}
}
