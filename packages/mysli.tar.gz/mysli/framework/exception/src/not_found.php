<?php

namespace mysli\framework\exception {
    class not_found extends base {}
}
